import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-travelagent-home',
  templateUrl: './travelagent-home.component.html',
  styleUrls: ['./travelagent-home.component.css']
})
export class TravelagentHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
