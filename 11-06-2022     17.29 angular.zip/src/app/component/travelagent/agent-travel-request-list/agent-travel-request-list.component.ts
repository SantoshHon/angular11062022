import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TravellingRequestDetails } from 'src/app/pojo/TravellingRequestDetails';
import { TravelingRequestDetailsService } from 'src/app/service/traveling-request-details.service';

@Component({
  selector: 'app-agent-travel-request-list',
  templateUrl: './agent-travel-request-list.component.html',
  styleUrls: ['./agent-travel-request-list.component.css']
})
export class AgentTravelRequestListComponent implements OnInit {

  allTravelRequests: TravellingRequestDetails[] = [];
  constructor(private travelingRequestDetailsService: TravelingRequestDetailsService, private router: Router) { }

  ngOnInit(): void {
    this.reloadData();
  }
  reloadData() {
    this.travelingRequestDetailsService.getAllAcceptedTravellingRequestDetailsForAgent().subscribe(
      data => {
        this.allTravelRequests = data;
        console.log(this.allTravelRequests);
      }
    )
  }

  getTravelDetails(travelRequestId: number) {
    console.log(travelRequestId);
    this.router.navigate(['/travelagenthome/validaterequest', travelRequestId]);
  }
}
