import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MakeNewBookingsComponent } from './make-new-bookings.component';

describe('MakeNewBookingsComponent', () => {
  let component: MakeNewBookingsComponent;
  let fixture: ComponentFixture<MakeNewBookingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MakeNewBookingsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MakeNewBookingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
