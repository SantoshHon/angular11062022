import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TravelDetails } from 'src/app/pojo/TravelDetails';
import { TravellingRequestDetails } from 'src/app/pojo/TravellingRequestDetails';
import { TravelingRequestDetailsService } from 'src/app/service/traveling-request-details.service';

@Component({
  selector: 'app-make-new-bookings',
  templateUrl: './make-new-bookings.component.html',
  styleUrls: ['./make-new-bookings.component.css']
})
export class MakeNewBookingsComponent implements OnInit {
  submitted: boolean = false;
  travelRequestId: number = 0;
  travelRequestDetails: TravellingRequestDetails = new TravellingRequestDetails();
  travelDetails: TravelDetails = new TravelDetails();
  constructor(private travelingRequestDetailsService: TravelingRequestDetailsService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.travelRequestId = this.route.snapshot.params['travelRequestId'];
  }
  onSubmitRequest() {
    console.log(this.travelRequestDetails);
    this.travelRequestDetails.travelRequestId=this.travelRequestId;
    this.travelRequestDetails.travelDetails=this.travelDetails;
    this.travelingRequestDetailsService.insertTravalDetails(this.travelRequestDetails).subscribe(
        data => {
          //  this.submitted=true;
           console.log(data);
          //  this.travelRequestDetails=data;
         
        }
      );
    // console.log(this.travelRequestDetails);
    // console.log(this.travelDetails);
  
   }
  goToHome() { }
}
  // this.travelingRequestDetailsService.submittravelRequest(this.travelRequestDetails).subscribe(
    //   data => {
    //     this.travelRequestDetails=data;
    //      this.submitted=true;
    //      console.log(data);
       
    //   }
    // );