import { Component, OnInit } from '@angular/core';
import { EmployeeDetails } from 'src/app/pojo/EmployeeDetails';
import { TravelDetails } from 'src/app/pojo/TravelDetails';
import { TraveldetailsServiceService } from 'src/app/service/traveldetails.service';

@Component({
  selector: 'app-booking-details',
  templateUrl: './booking-details.component.html',
  styleUrls: ['./booking-details.component.css']
})
export class BookingDetailsComponent implements OnInit {
  travelDetails: TravelDetails[] = [];
  employeeDetails:EmployeeDetails=new EmployeeDetails();
  constructor(private traveldetailsServiceService: TraveldetailsServiceService) { }

  ngOnInit(): void {
     this.reloadData();
  }
  reloadData(){
    this.traveldetailsServiceService.getAllTravelDetails().subscribe(
      data => {
        this.travelDetails=data;
        console.log(this.travelDetails);
    
      }
    );
  }
}
