import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeDetails } from 'src/app/pojo/EmployeeDetails';
import { SlabMaster } from 'src/app/pojo/SlabMaster';
import { TravellingRequestDetails } from 'src/app/pojo/TravellingRequestDetails';
import { SlabMasterService } from 'src/app/service/slab-master.service';
import { TravelingRequestDetailsService } from 'src/app/service/traveling-request-details.service'


@Component({
  selector: 'app-validate-request',
  templateUrl: './validate-request.component.html',
  styleUrls: ['./validate-request.component.css']
})


export class ValidateRequestComponent implements OnInit {
  agentAction: string = '';
  travelRequestId: number = 0;
  travellingRequestDetails: TravellingRequestDetails = new TravellingRequestDetails();
  employeeDetails: EmployeeDetails = new EmployeeDetails();
  constructor(private slabMasterService: SlabMasterService, private travelingRequestDetailsService: TravelingRequestDetailsService, private route: ActivatedRoute,private router:Router) { }

  slabMasters: SlabMaster[] = [];
  ngOnInit(): void {
    this.travelRequestId = this.route.snapshot.params['travelRequestId'];
    this.loadSlabMaster();
    this.loadTravelRequest(this.travelRequestId);
  }
  loadSlabMaster() {
    this.slabMasterService.getAllSlabMaster().subscribe(
      data => {
        this.slabMasters = data;

      }
    )
  }

  loadTravelRequest(travelRequestId: number) {
    this.travelingRequestDetailsService.getTravellingRequestDetailsBytravelRequestId(this.travelRequestId).subscribe(
      data => {
        this.travellingRequestDetails = data;
        this.employeeDetails=this.travellingRequestDetails.employeeDetails;
      }
    );
  }

  approveButton(travelRequestId:number) {
    this.agentAction = 'APPROVED';
    this.travellingRequestDetails.tarvelStatus = this.agentAction;
    this.updateStatus();
    this.router.navigate(['/travelagenthome/makenewbookings',travelRequestId]);

  }

  rejectButton() {
    this.agentAction = 'REJECTED';
    this.travellingRequestDetails.tarvelStatus = this.agentAction;
    console.log(TravellingRequestDetails);

    this.updateStatus();
  }

  updateStatus() {
    this.travelingRequestDetailsService.updateTravelRequestStatus(this.travellingRequestDetails).subscribe(
      data => {
        console.log(data);

      }
    );
  }
}