import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewManagerBookingStatusComponent } from './view-manager-booking-status.component';

describe('ViewManagerBookingStatusComponent', () => {
  let component: ViewManagerBookingStatusComponent;
  let fixture: ComponentFixture<ViewManagerBookingStatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewManagerBookingStatusComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewManagerBookingStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
