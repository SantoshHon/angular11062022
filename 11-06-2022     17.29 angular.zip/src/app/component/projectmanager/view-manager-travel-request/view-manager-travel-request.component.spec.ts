import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewManagerTravelRequestComponent } from './view-manager-travel-request.component';

describe('ViewManagerTravelRequestComponent', () => {
  let component: ViewManagerTravelRequestComponent;
  let fixture: ComponentFixture<ViewManagerTravelRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewManagerTravelRequestComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewManagerTravelRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
