import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeDetails } from 'src/app/pojo/EmployeeDetails';
import { TravellingRequestDetails } from 'src/app/pojo/TravellingRequestDetails';
import { TravelingRequestDetailsService } from 'src/app/service/traveling-request-details.service';

@Component({
  selector: 'app-view-travel-request',
  templateUrl: './view-travel-request.component.html',
  styleUrls: ['./view-travel-request.component.css']
})
export class ViewTravelRequestComponent implements OnInit {
  allTravelRequests: TravellingRequestDetails[] = [];
  employeeDetails: EmployeeDetails = new EmployeeDetails();
  employeeDetailsId: number = 0;
  constructor(private travelingRequestDetailsService: TravelingRequestDetailsService, private router: Router) { }

  ngOnInit(): void {
    
    this.employeeDetails = JSON.parse(sessionStorage.getItem('employee') || '{}');
    this.employeeDetailsId = this.employeeDetails.employeeDetailsId;
    console.log(this.employeeDetailsId);
    this.reloadData();

  }
  reloadData() {
    this.travelingRequestDetailsService.getAllTravellingRequestDetailsByEmployeeId(this.employeeDetailsId).subscribe(
      data => {    
        this.allTravelRequests = data;
        console.log(this.allTravelRequests);
      }
    )
  }

  getdetails(travelRequestId: Number) {
    // this.router.navigate(['/employeehome/employeetraveldetails', travelRequestId]);
    this.router.navigate(['/employeehome/viewbookingstatus',travelRequestId]);
  }
}
