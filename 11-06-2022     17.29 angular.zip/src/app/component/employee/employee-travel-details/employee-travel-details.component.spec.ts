import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeTravelDetailsComponent } from './employee-travel-details.component';

describe('EmployeeTravelDetailsComponent', () => {
  let component: EmployeeTravelDetailsComponent;
  let fixture: ComponentFixture<EmployeeTravelDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmployeeTravelDetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmployeeTravelDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
