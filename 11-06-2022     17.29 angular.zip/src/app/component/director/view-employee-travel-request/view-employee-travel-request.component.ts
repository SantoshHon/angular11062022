import { Component, OnInit } from '@angular/core';
import { TravellingRequestDetails } from 'src/app/pojo/TravellingRequestDetails';
import { TravelingRequestDetailsService } from 'src/app/service/traveling-request-details.service';

@Component({
  selector: 'app-view-employee-travel-request',
  templateUrl: './view-employee-travel-request.component.html',
  styleUrls: ['./view-employee-travel-request.component.css']
})

export class ViewEmployeeTravelRequestComponent implements OnInit {

  constructor(private travelingRequestDetailsService:TravelingRequestDetailsService) { }

  trravellingRequestDetails:TravellingRequestDetails[]=[];
  ngOnInit(): void {
    this.loadBookingDetails();
  }
  loadBookingDetails(){
    this.travelingRequestDetailsService.getAllTravellingRequestDetailsForDirector().subscribe(
      data=>{
        this.trravellingRequestDetails=data;
        console.log(this.trravellingRequestDetails);
      }
    )
  }
  getdetails(){}

}