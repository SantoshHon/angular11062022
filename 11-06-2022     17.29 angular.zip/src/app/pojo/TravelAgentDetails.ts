import { LoginDetails } from "./logindetails";
import { SlabMaster } from "./SlabMaster";

export class travelAgentDetails {
	agentId: number = 0;
	travelAgentName: string = '';
	slabMaster: SlabMaster = new SlabMaster();
	loginDetails: LoginDetails = new LoginDetails();

}