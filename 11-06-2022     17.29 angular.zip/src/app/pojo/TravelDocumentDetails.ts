
export class TravelDocumentDetails {
    documentId: number = 0;
    documentType: string = '';
    documentName: string = '';
    
}