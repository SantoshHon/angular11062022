export class SlabMaster {
    slabMasterId: number = 0;
    designation: string = '';
    slab: number = 0;
    travelMode: string = '';
}