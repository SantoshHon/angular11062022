import { LoginDetails } from "./logindetails";

export class EmployeeDetails {
    employeeDetailsId: number = 0;
    firstName: string = '';
    lastName: string = '';
    address: string = '';
    managerId: number = 0;
    city: string = '';
    state: string = '';
    emailId: string = '';
    designation: string = '';
    loginDetails: LoginDetails = new LoginDetails();
}
