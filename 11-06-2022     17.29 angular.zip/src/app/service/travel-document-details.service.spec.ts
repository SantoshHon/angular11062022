import { TestBed } from '@angular/core/testing';

import { TravelDocumentDetailsService } from './travel-document-details.service';

describe('TravelDocumentDetailsService', () => {
  let service: TravelDocumentDetailsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TravelDocumentDetailsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
