import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { SlabMaster } from '../pojo/SlabMaster';

@Injectable({
  providedIn: 'root'
})
export class SlabMasterService {
  private baseURL: string = "http://localhost:8080/slab/slabmaster";
  constructor(private http: HttpClient) { }

  getAllSlabMaster(): Observable<SlabMaster[]> {
    return this.http.get<SlabMaster[]>(this.baseURL);
  }

  getSlabMasterByslabMasterId(slabMasterId: number): Observable<SlabMaster> {
    console.log('in get single employee'+slabMasterId);
    return this.http.get<SlabMaster>(this.baseURL + '/' + slabMasterId);
  }
}
